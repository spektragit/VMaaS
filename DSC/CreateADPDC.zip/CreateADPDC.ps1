configuration CreateADPDC
{ 
	  param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )

Get-WindowsFeature AD-Domain-Services | Install-WindowsFeature
Import-Module ADDSDeployment
$ADRestorePassword="demopassword1!"
# Variables
$NetBIOSName = $DomainName.Split(".") | Select -First 1
$DatabasePath = "C:\ADDS\NTDS"
$SYSVOLPath = "C:\ADDS\SYSVOL"
$LogPath = "C:\ADDS\Logs"
$RestorePassword = ConvertTo-SecureString -String $ADRestorePassword -AsPlainText -Force
# Install Required Windows Features
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools
# Create AD Domain
$ADinstall= Install-ADDSForest -DomainName $DomainName `
                   -DomainNetbiosName $NetBIOSName `
                   -ForestMode "WinThreshold" `
                   -DomainMode "WinThreshold" `
                   -InstallDns:$true `
                   -DatabasePath $DatabasePath `
                   -SYSVOLPath $SYSVOLPath `
                   -LogPath $LogPath `
                   -SafeModeAdministratorPassword $RestorePassword `
                   -NoRebootonCompletion:$false `
                   -Force

}

