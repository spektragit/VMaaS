configuration CreateADPDC
{ 
	  param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )


$ADRestorePassword="demopassword1!"
# Variables
$NetBIOSName = $DomainName.Split(".") | Select -First 1
$ForestMode = "Win2012R2"
$DomainMode = "Win2012R2"
$DatabasePath = "C:\ADDS\NTDS"
$SYSVOLPath = "C:\ADDS\SYSVOL"
$LogPath = "C:\ADDS\Logs"
$RestorePassword = ConvertTo-SecureString -String $ADRestorePassword -AsPlainText -Force
# Install Required Windows Features
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools
# Create AD Domain
$ADinstall= Install-ADDSForest -DomainName $DomainName `
                   -DomainNetbiosName $NetBIOSName `
                   -ForestMode $ForestMode `
                   -DomainMode $DomainMode `
                   -DatabasePath $DatabasePath `
                   -SYSVOLPath $SYSVOLPath `
                   -LogPath $LogPath `
                   -SafeModeAdministratorPassword $RestorePassword `
                   -NoRebootonCompletion:$true `
                   -Force

}

